ZIVORA | زیورا
نسخه آماده برای GitHub Pages

فایل اصلی سایت: index.html

نحوه انتشار:
1. فایل‌های داخل ZIP را در مخزن GitHub قرار دهید.
2. در Settings > Pages گزینه Deploy from a branch را انتخاب کنید.
3. Branch اصلی (معمولاً main) و پوشه / (root) را انتخاب کنید.
